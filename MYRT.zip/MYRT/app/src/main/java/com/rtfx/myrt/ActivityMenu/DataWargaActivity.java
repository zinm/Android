package com.rtfx.myrt.ActivityMenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.rtfx.myrt.R;

import java.util.ArrayList;

public class DataWargaActivity extends AppCompatActivity {
    ListView listView;
    EditText inputtext1;
    Button btnadd, btnupdate;

    ArrayList<String> foods = new ArrayList<String>();
    ArrayAdapter myAdapter1;

    Integer indexVal;
    String item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_warga);

        listView = (ListView) findViewById(R.id.listview);
        btnadd = (Button) findViewById(R.id.btn_add);
        btnupdate = (Button) findViewById(R.id.btn_update);
        inputtext1 = (EditText) findViewById(R.id.text1);


        myAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, foods);
        listView.setAdapter(myAdapter1);

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringval = inputtext1.getText().toString();
                foods.add(stringval);
                myAdapter1.notifyDataSetChanged();
                inputtext1.setText("");

            }
        });

        }

    }
