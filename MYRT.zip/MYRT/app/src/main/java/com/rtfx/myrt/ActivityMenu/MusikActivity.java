package com.rtfx.myrt.ActivityMenu;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.rtfx.myrt.R;

public class MusikActivity extends AppCompatActivity {
    private SoundPool soundPool;
    private int sound1, sound2, sound3, sound4, sound5, sound6, sound7, sound8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_musik);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            soundPool = new SoundPool.Builder()
                    .setMaxStreams(8)
                    .setAudioAttributes(audioAttributes)
                    .build();
        } else {
         soundPool = new SoundPool(8, AudioManager.STREAM_MUSIC, 0);
        }
        sound1 = soundPool.load(this, R.raw.doo, 1);
        sound2 = soundPool.load(this, R.raw.ree, 1);
        sound3 = soundPool.load(this, R.raw.mii, 1);
        sound4 = soundPool.load(this, R.raw.faa, 1);
        sound5 = soundPool.load(this, R.raw.sol, 1);
        sound6 = soundPool.load(this, R.raw.laa, 1);
        sound7 = soundPool.load(this, R.raw.sii, 1);
        sound8 = soundPool.load(this, R.raw.dooo, 1);
    }

    public void playSound(View v){
        switch (v.getId()){
            case R.id.DO:
                soundPool.play(sound1,1,8,0,0, 1);
                break;
            case R.id.RE:
                soundPool.play(sound2,1,8,0, 0,1);
                break;
            case R.id.MI:
                soundPool.play(sound3,1,8,0,0, 1);
                break;
            case R.id.FA:
                soundPool.play(sound4,1,8,0,0, 1);
                break;
            case R.id.SOL:
                soundPool.play(sound5,1,8,0,0, 1);
                break;
            case R.id.LA:
                soundPool.play(sound6,1,8,0,0, 1);
                break;
            case R.id.SI:
                soundPool.play(sound7,1,8,0,0, 1);
                break;
            case R.id.DOO:
                soundPool.play(sound8,1,8,0,0, 1);
                break;
        }
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        soundPool.release();
        soundPool = null;

    }
}
