package com.rtfx.myrt.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.rtfx.myrt.ActivityMenu.DataWargaActivity;
import com.rtfx.myrt.R;
import com.rtfx.myrt.ActivityMenu.JadwalRondaActivity;
import com.rtfx.myrt.ActivityMenu.MusikActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void musikView(View view) {
        Intent intent = new Intent(HomeActivity.this, MusikActivity.class);
        startActivity(intent);
    }

    public void jadwalRonda(View i) {
        Intent intent = new Intent(HomeActivity.this, JadwalRondaActivity.class);
        startActivity(intent);
    }

    public void dataView(View q) {
        Intent intent = new Intent(HomeActivity.this, DataWargaActivity.class);
        startActivity(intent);
    }
}
