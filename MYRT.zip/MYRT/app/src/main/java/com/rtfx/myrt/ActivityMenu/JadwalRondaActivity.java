package com.rtfx.myrt.ActivityMenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.rtfx.myrt.R;

public class JadwalRondaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_ronda);
    }
}
